//
//  ViewController.swift
//  Reproductor de Música
//
//  Created by Javier Oñate Mendía on 2/10/16.
//  Copyright © 2016 Dédalo. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource  {

    @IBOutlet weak var portada: UIImageView!
    @IBOutlet weak var pista: UILabel!
    @IBOutlet weak var autor: UILabel!
    @IBOutlet weak var disco: UILabel!
    @IBOutlet weak var seleccion: UIPickerView!
 
    private var reproductor: AVAudioPlayer!
    
    var pistas: [String] = [String]()
    var pistaSeleccionada: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.pista.text = ""
        self.autor.text = ""
        self.disco.text = ""
        self.pistas = ["Pistas","Las Canastas", "Son de la Loma", "Spiritual", "Strange Fruit", "Der Hoelle Rache"]
        self.seleccion.delegate = self
        self.seleccion.dataSource = self
    }

    // The number of columns of data
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pistas.count
    }
    
    // The data to return for the row and component (column) that's being passed in
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pistas[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        var reproducir: Int = 0  // bandera para indicar si se selecciono una pista o el titulo del picker
        
        switch(row){
            case 1:
                reproducir = 1
                self.pistaSeleccionada = "lasCanastas"
                self.pista.text = "Las Canastas"
                self.autor.text = "Ernesto Anaya"
                self.disco.text = "Huapangueando"
                self.portada.image = UIImage(named: "lasCanastasPortada")
                break
            case 2:
                reproducir = 1
                self.pistaSeleccionada = "sonDeLaLoma"
                self.pista.text = "Son de la loma"
                self.autor.text = "Bebo & Chucho Valdes"
                self.disco.text = "Juntos para siempre"
                self.portada.image = UIImage(named: "sonDeLaLomaPortada")
                break
            case 3:
                reproducir = 1
                self.pistaSeleccionada = "spiritual"
                self.pista.text = "Spiritual"
                self.autor.text = "John Coltrane"
                self.disco.text = "John Coltrane Gold"
                self.portada.image = UIImage(named: "spiritualPortada")
                break
            case 4:
                reproducir = 1
                self.pistaSeleccionada = "strangeFruit"
                self.pista.text = "Strange Fruit"
                self.autor.text = "Billie Holliday"
                self.disco.text = "La Flauta Mágica"
                self.portada.image = UIImage(named: "strangeFruitPortada")
                break
            case 5:
                reproducir = 1
                self.pistaSeleccionada = "derHoelleRache"
                self.pista.text = "Der Hoelle Rache ..."
                self.autor.text = "W. A. Mozart"
                self.disco.text = "La Flauta Mágica"
                self.portada.image = UIImage(named: "derHoelleRachePortada")
                break
            default:
                reproducir = 0
                self.pistaSeleccionada = ""
                self.pista.text = ""
                self.autor.text = ""
                self.disco.text = ""
                self.portada.image = UIImage(named: "")
                self.parar()
                break
        }
        
        // si se selecciono una pista
        if reproducir == 1 {
            do{
                let pistaURL = NSBundle.mainBundle().URLForResource(self.pistaSeleccionada, withExtension: "m4a")!
                try reproductor = AVAudioPlayer(contentsOfURL: pistaURL)
                self.tocar()
            }catch{
                
            }
        }
    }
    
    func tocar(){
        self.parar()
        reproductor.play()
    }
    
    func parar(){
        if reproductor.playing{
            reproductor.stop()
        }
    }
}

