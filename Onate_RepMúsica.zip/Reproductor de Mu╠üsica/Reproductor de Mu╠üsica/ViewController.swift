//
//  ViewController.swift
//  Reproductor de Música
//
//  Created by Javier Oñate Mendía on 2/10/16.
//  Copyright © 2016 Dédalo. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource  {

    @IBOutlet weak var portada: UIImageView!
    @IBOutlet weak var pista: UILabel!
    @IBOutlet weak var autor: UILabel!
    @IBOutlet weak var disco: UILabel!
    @IBOutlet weak var seleccion: UIPickerView!
    @IBOutlet weak var volumen: UILabel!
 
    private var reproductor: AVAudioPlayer!
    var pistas: [String] = [String]()
    var pistaSeleccionada: String = ""
    let tamanoImagen = CGSizeMake(170, 170)
    
    // funciones de storyBoard
    @IBAction func iniciar() {
        self.tocar()
    }
    
    @IBAction func pausar() {
        if reproductor.playing{
            reproductor.pause()
        }
    }
    
    @IBAction func suspender() {
        self.parar()
    }
    
    @IBAction func aleatorio() {
        
//        let cual = arc4random_uniform(5) + 1
        let indice: Int = Int.init(arc4random_uniform(5) + 1)
        self.tocarSeleccion(indice)
    }
    
    @IBAction func subirVolumen() {
        if self.reproductor.volume < 1.0{
            self.reproductor.volume += 0.1
            self.ponerVolumen()
        }
    }
    
    @IBAction func bajarVolumen() {
        if self.reproductor.volume > 0.0{
            self.reproductor.volume -= 0.1
            self.ponerVolumen()
        }
    }
    
    // funciones dafault
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.pista.text = ""
        self.autor.text = ""
        self.disco.text = ""
        self.volumen.text = ""
        self.pistas = ["Pistas","Las Canastas", "Son de la Loma", "Spiritual", "Strange Fruit", "Der Hoelle Rache"]
        self.seleccion.delegate = self
        self.seleccion.dataSource = self
    }

    // funciones pickerView
    
    // The number of columns of data
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pistas.count
    }
    
    // The data to return for the row and component (column) that's being passed in
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pistas[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.tocarSeleccion(row)
    }

    
    // funciones jom
    func tocarSeleccion(cual: Int){

        var reproducir: Int = 0  // bandera para indicar si se selecciono una pista o el titulo del picker
        
        switch(cual){
        case 1:
            reproducir = 1
            self.pistaSeleccionada = "lasCanastas"
            self.pista.text = "Las Canastas"
            self.autor.text = "Ernesto Anaya"
            self.disco.text = "Huapangueando"
            let imagen = UIImage(named: "lasCanastasPortada")!
            self.portada.image = imageResize(image: imagen,sizeChange: self.tamanoImagen)
            break
        case 2:
            reproducir = 1
            self.pistaSeleccionada = "sonDeLaLoma"
            self.pista.text = "Son de la loma"
            self.autor.text = "Bebo & Chucho Valdes"
            self.disco.text = "Juntos para siempre"
            let imagen = UIImage(named: "sonDeLaLomaPortada")!
            self.portada.image = imageResize(image: imagen,sizeChange: self.tamanoImagen)
            break
        case 3:
            reproducir = 1
            self.pistaSeleccionada = "spiritual"
            self.pista.text = "Spiritual"
            self.autor.text = "John Coltrane"
            self.disco.text = "John Coltrane Gold"
            let imagen = UIImage(named: "spiritualPortada")!
            self.portada.image = imageResize(image: imagen,sizeChange: self.tamanoImagen)
            break
        case 4:
            reproducir = 1
            self.pistaSeleccionada = "strangeFruit"
            self.pista.text = "Strange Fruit"
            self.autor.text = "Billie Holliday"
            self.disco.text = "Golden Years"
            let imagen = UIImage(named: "strangeFruitPortada")!
            self.portada.image = imageResize(image: imagen,sizeChange: self.tamanoImagen)
            break
        case 5:
            reproducir = 1
            self.pistaSeleccionada = "derHoelleRache"
            self.pista.text = "Der Hoelle Rache ..."
            self.autor.text = "W. A. Mozart"
            self.disco.text = "La Flauta Mágica"
            let imagen = UIImage(named: "derHoelleRachePortada")!
            self.portada.image = imageResize(image: imagen,sizeChange: self.tamanoImagen)
            break
        default:
            reproducir = 0
            self.pistaSeleccionada = ""
            self.pista.text = ""
            self.autor.text = ""
            self.disco.text = ""
            self.portada.image = UIImage(named: "")
            self.parar()
            break
        }
        
        // si se selecciono una pista
        if reproducir == 1 {
            do{
                let pistaURL = NSBundle.mainBundle().URLForResource(self.pistaSeleccionada, withExtension: "m4a")!
                try reproductor = AVAudioPlayer(contentsOfURL: pistaURL)
                self.ponerVolumen()
                self.tocar()
            }catch{
                
            }
        }
    }
    
    func tocar(){
        self.parar()
        reproductor.play()
    }
    
    func parar(){
        if reproductor.playing{
            reproductor.stop()
            reproductor.currentTime = 0.0
        }
    }
    
    func ponerVolumen(){
        let volumen: String = String(format:"%.1f", reproductor.volume)
        self.volumen.text = volumen
    }
    
    func imageResize (image image:UIImage, sizeChange:CGSize)-> UIImage{
        
        let hasAlpha = true
        let scale: CGFloat = 0.0 // Use scale factor of main screen
        
        UIGraphicsBeginImageContextWithOptions(sizeChange, !hasAlpha, scale)
        image.drawInRect(CGRect(origin: CGPointZero, size: sizeChange))
        
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        return scaledImage
    }
    
    
}

