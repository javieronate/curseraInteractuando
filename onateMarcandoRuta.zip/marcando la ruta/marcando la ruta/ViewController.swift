//
//  ViewController.swift
//  marcando la ruta
//
//  Created by Javier Oñate Mendía on 2/12/16.
//  Copyright © 2016 Dédalo. All rights reserved.
//

import UIKit
import MapKit


class ViewController: UIViewController, CLLocationManagerDelegate {

    
    
    @IBOutlet weak var mapa: MKMapView!
    
    
    private let manejador = CLLocationManager()
    
    @IBAction func satelite() {
        self.mapa.mapType = MKMapType.Satellite
    }
    
    @IBAction func hibrido() {
        self.mapa.mapType = MKMapType.Hybrid
    }
    
    @IBAction func mapaBoton() {
        self.mapa.mapType = MKMapType.Standard
    }

    @IBAction func iniciar() {
        self.manejador.startUpdatingLocation()
    }
    
    @IBAction func suspender() {
        self.manejador.stopUpdatingLocation()
    }
    
    @IBAction func acercarse() {
        if self.amplificacion > 500{
            self.amplificacion -= 500
            self.actualizarMapa()
        }
    }
    
    @IBAction func alejarse() {
        self.amplificacion += 500
        self.actualizarMapa()
    }
    
   
    
    
    var inicioDeMedicion: Int = 1
    var puntoInicial: CLLocation? = nil
    var amplificacion: Double = 2000
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        manejador.delegate = self
        manejador.desiredAccuracy = kCLLocationAccuracyBest
        manejador.distanceFilter =  50
        manejador.requestWhenInUseAuthorization()
        
        self.mapa.mapType = MKMapType.Standard
    }
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        var distanciaRecorrida:Double = 0.0
        var punto = CLLocationCoordinate2D()
        punto.latitude = manager.location!.coordinate.latitude
        punto.longitude = manager.location!.coordinate.longitude

        if self.inicioDeMedicion == 1 {
            self.puntoInicial = CLLocation.init(latitude: punto.latitude, longitude: punto.longitude)
            self.inicioDeMedicion = 0
        }else{
            let nuevoPunto:CLLocation = CLLocation.init(latitude: punto.latitude, longitude: punto.longitude)
            distanciaRecorrida = nuevoPunto.distanceFromLocation(self.puntoInicial!)
        }
        
        let pin = MKPointAnnotation()
        pin.title = "Long.: \(punto.longitude) ; Lat.: \(punto.latitude)"
        pin.subtitle = "Distancia recorrida: \(distanciaRecorrida)"
        pin.coordinate = punto
        mapa.addAnnotation(pin)
        self.actualizarMapa()
    }

    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        let alerta = UIAlertController(title: "Error", message: "error: \(error.code)", preferredStyle: .Alert)
        let actionOk = UIAlertAction(title: "Ok", style: .Default, handler: {accion in
         //...
        })
        alerta.addAction(actionOk)
        self.presentViewController(alerta, animated: true, completion: nil)
    }
    
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        if status == .AuthorizedWhenInUse{
            mapa.showsUserLocation = true
        }else{
            mapa.showsUserLocation = false
        }
    }

    func actualizarMapa(){
        let userLocation = mapa.userLocation
        let region = MKCoordinateRegionMakeWithDistance(userLocation.location!.coordinate, self.amplificacion, self.amplificacion)
        mapa.setRegion(region, animated: true)
    }

}

